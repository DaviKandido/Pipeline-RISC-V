# LaTeX — Trabalho Prático 2 (formato article + SBC)

## O que foi feito

O conteúdo do seu artigo (template SBC Reviews) foi reorganizado no **formato modular** do segundo modelo:

- `main.tex` — preâmbulo, título, autores e `\input`/`\include` das seções
- `texto/pre-texto/resumo.tex` — resumo (PT), abstract (EN) e palavras-chave
- `texto/secoes/*.tex` — seções do corpo do texto
- `referencias/referencias.bib` — referência mínima (livro Patterson)

## Dependência obrigatória

O `main.tex` usa `\usepackage{sbc-template}`. Esse arquivo **não vem neste repositório**.

Copie do seu projeto do seminário (ou do pacote da disciplina):

- `sbc-template.sty`
- (se o compilador reclamar) `sbc.bst` e demais arquivos que o seu seminário usa na mesma pasta do `main.tex` ou no `TEXINPUTS`

Coloque `sbc-template.sty` **na pasta `latex_tp2/`** (ao lado de `main.tex`).

## Figuras

No artigo original as figuras apontavam para:

`SBC-Reviews-Class-Latex-v1.0/images/...`

Aqui usamos a pasta local:

`latex_tp2/images/`

**Copie** para `latex_tp2/images/`:

- `pipeline1.png`
- `pipeline2.jpeg`
- `arquivosEmPasta.png`

## Compilação (exemplo)

```bash
cd latex_tp2
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Ou `latexmk -pdf main.tex` se você usa `latexmk`.
